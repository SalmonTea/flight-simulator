This F4-E Phantom model has been downloaded from 3D Kingdom.org (http://www.3dkingdom.org) !



Design:
MD F4-E Phantom Low Poly Model. By Kirk Longendyke 2003

The model has parts that are left out of this 3DS file for a specific reason.
Most of the undercarage needs work on this model. Most of the areas are layed out for you. Such as the hard points and landing gear. 

All parts are movable!

Thanks

Kirk Long
http://unitedflight.totalpilot.com
kirk@totalpilot.com
